<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 28.02.2018
 * Time: 12:27
 */

namespace esas\hutkigrosh\protocol;


class LoginRs extends HutkigroshRs
{

}
<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 17.08.2018
 * Time: 8:38
 */

namespace esas\hutkigrosh;

class ConfigurationFieldsModx extends ConfigurationFields
{
    const SUCCESS_RESOURCE_ID = 'hutkigrosh_success_resource_id';
    const FAILED_RESOURCE_ID = 'hutkigrosh_failed_resource_id';
}
<?php
/**
 * Created by PhpStorm.
 * User: nikit
 * Date: 17.08.2018
 * Time: 11:09
 */

namespace esas\hutkigrosh;


class ViewFields
{
    const ALFACLICK_LABEL = 'hutkigrosh_alfaclick_label';
    const ALFACLICK_MSG_SUCCESS = 'hutkigrosh_alfaclick_msg_success';
    const ALFACLICK_MSG_UNSUCCESS = 'hutkigrosh_alfaclick_msg_unsuccess';
    const WEBPAY_MSG_SUCCESS = 'hutkigrosh_webpay_msg_success';
    const WEBPAY_MSG_UNSUCCESS = 'hutkigrosh_webpay_msg_unsuccess';
}